from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Header, Depends
import uvicorn
import os
import shutil
import json
from process_resumes import process_all_resumes
from rank_candidates import compute_relative_ranking
from supabase import create_client
from dotenv import load_dotenv
import uuid
import jwt

# Load environment variables from .env file
load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    raise ValueError("Supabase URL or API Key not found in environment variables.")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

from routes.comparison import router as comparison_router
from routes.collaboration import router as collaboration_router
from routes.search_analytics import router as search_router
from routes.my_screenings import router as screenings_router

app = FastAPI()
app.include_router(comparison_router)
app.include_router(collaboration_router)
app.include_router(search_router)
app.include_router(screenings_router)

RESUME_FOLDER= "resumes"
UPLOAD_FOLDER = "uploads"
PROCESSED_DATA_FOLDER = "processed_data"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PROCESSED_DATA_FOLDER, exist_ok=True)

def get_current_user(authorization: str = Header(...)):
    token = authorization.split(" ")[-1]
    decoded = jwt.decode(token, options={"verify_signature": False})
    return decoded.get("sub")  # Supabase user ID

@app.post("/upload-resumes/")
async def upload_resumes(
    file: UploadFile = File(...),
    job_description: str = Form(...),
    job_title: str = Form(...),
    weight_experience: int = Form(...),
    weight_projects: int = Form(...),
    user_id: str = Depends(get_current_user)
):
    job_id = str(uuid.uuid4())
    zip_filename = f"{job_id}.zip"
    zip_path = os.path.join(UPLOAD_FOLDER, zip_filename)
    resume_output_folder = os.path.join(RESUME_FOLDER, job_id)
    os.makedirs(resume_output_folder, exist_ok=True)

    try:
        with open(zip_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        print(f"File {file.filename} uploaded and renamed to {zip_filename}.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"File upload failed: {str(e)}")

    if os.path.getsize(zip_path) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    weightages = {
        "experience": weight_experience,
        "projects": weight_projects
    }

    try:
        job_id = upload_job_description_to_db(job_id, job_title, job_description, weight_experience, weight_projects, user_id)
        if not job_id:
            raise HTTPException(status_code=500, detail="Job description upload failed.")

        process_all_resumes(zip_path, job_description, weightages, resume_output_folder)

        resume_id_map = {}
        for resume in os.listdir(resume_output_folder):
            file_name = resume
            file_path = os.path.join(resume_output_folder, resume)
            resume_id = upload_resume_info_to_db(file_name, file_path, job_id, user_id)
            if resume_id:
                resume_id_map[file_name] = resume_id

        upload_analysis_to_db(resume_id_map)
        supabase.rpc("update_resume_ranks", {"job": job_id}).execute()
        print(f"Rankings updated for job: {job_id}")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Resume processing failed: {str(e)}")

    return {"message": "Resumes processed & uploaded successfully!", "job_id": job_id}

def upload_job_description_to_db(job_id, job_title, job_description, exp_weight, proj_weight, user_id):
    try:
        data = {
            "job_id": job_id,
            "user_id": user_id,
            "job_title": job_title,
            "job_description": job_description,
            "experience_weight": exp_weight,
            "project_weight": proj_weight
        }
        supabase.table("job_descriptions").insert(data).execute()
        print(f"Uploaded job description with weights. Job ID: {job_id}")
        return job_id
    except Exception as e:
        print(f"Error uploading job description: {str(e)}")
        return None

def upload_resume_info_to_db(file_name, file_path, job_id, user_id):
    resume_id = str(uuid.uuid4())
    data = {
        "resume_id": resume_id,
        "user_id": user_id,
        "job_id": job_id,
        "file_name": file_name,
        "file_path": file_path,
    }
    try:
        supabase.table("resume_uploads").insert(data).execute()
        print(f"Uploaded resume metadata for {file_name} with resume_id {resume_id}")
        return resume_id
    except Exception as e:
        print(f"Error uploading resume info for {file_name}: {str(e)}")
        return None

def upload_analysis_to_db(resume_id_map):
    output_json = os.path.join(PROCESSED_DATA_FOLDER, "resume_analysis.json")
    with open(output_json, "r") as f:
        results = json.load(f)

    for result in results:
        analysis = result["analysis"]
        file_name = result["filename"]

        resume_id = resume_id_map.get(file_name)
        if not resume_id:
            print(f"Error: Resume ID not found for file name {file_name}")
            continue

        supabase.table("resume_analysis").delete().eq("resume_id", resume_id).execute()

        data = {
            "resume_id": resume_id,
            "key_skills": analysis.get("Key Skills", []),
            "overall_analysis": analysis.get("Overall Analysis", ""),
            "certifications_courses": analysis.get("Certifications & Courses", []),
            "relevant_projects": analysis.get("Relevant Projects", []),
            "soft_skills": analysis.get("Soft Skills", []),
            "overall_match_score": analysis.get("Overall Match Score", 0),
            "projects_relevance_score": analysis.get("Projects Relevance Score", 0),
            "experience_relevance_score": analysis.get("Experience Relevance Score", 0)
        }

        try:
            supabase.table("resume_analysis").insert(data).execute()
            print(f"Uploaded analysis for {file_name}")
        except Exception as e:
            print(f"Error uploading analysis for {file_name}: {str(e)}")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8080)
