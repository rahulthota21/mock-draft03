from sklearn.preprocessing import MinMaxScaler
import json
import pandas as pd
import os

# Paths
PROCESSED_DATA_FOLDER = "processed_data"
INPUT_JSON = os.path.join(PROCESSED_DATA_FOLDER, "resume_analysis.json")
OUTPUT_JSON = os.path.join(PROCESSED_DATA_FOLDER, "ranked_candidates.json")
OUTPUT_CSV = os.path.join(PROCESSED_DATA_FOLDER, "ranked_candidates.csv")

# Compute Relative Ranking
def compute_relative_ranking():
    # Check if input file exists
    if not os.path.exists(INPUT_JSON):
        print("Error: No processed resumes found.")
        return

    # Load Processed Resumes
    with open(INPUT_JSON, "r") as f:
        resume_results = json.load(f)

    # Check for empty data
    if not resume_results:
        print("Error: No valid resume data to rank.")
        return

    # Extract Scores
    scores = [
        [r["analysis"].get("Final Score", 0)]
        for r in resume_results
        if "Final Score" in r["analysis"]
    ]

    # Handle Empty or Invalid Scores
    if not scores:
        print("Error: No valid scores found for ranking.")
        return

    # Normalize Scores
    scaler = MinMaxScaler()
    normalized_scores = scaler.fit_transform(scores)

    # Assign Relative Ranking
    for i, resume in enumerate(resume_results):
        resume["analysis"]["Relative Ranking Score"] = round(normalized_scores[i][0] * 100, 2)

    # Sort by Ranking
    ranked_results = sorted(resume_results, key=lambda x: x["analysis"].get("Relative Ranking Score", 0), reverse=True)

    # Save JSON & CSV
    with open(OUTPUT_JSON, "w") as f:
        json.dump(ranked_results, f, indent=4)

    df = pd.DataFrame([
        {"filename": r["filename"], **r["analysis"]}
        for r in ranked_results
    ])
    df.to_csv(OUTPUT_CSV, index=False)

    print("Ranking Complete!")

if __name__ == "__main__":
    compute_relative_ranking()
