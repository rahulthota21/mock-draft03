import openai
import json
import os
import pdfminer
from pdfminer.high_level import extract_text
import docx
import numpy as np
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
from sentence_transformers import SentenceTransformer
from tqdm import tqdm
import time
import zipfile
import shutil
import os
from dotenv import load_dotenv

load_dotenv()
# Load Sentence Transformer Model
embed_model = SentenceTransformer("all-MiniLM-L6-v2")
GROQ_API_KEY=os.getenv("OPENAI_API_KEY")
# Set up Groq API for Mistral-Saba-24B
client = openai.OpenAI(
    api_key=GROQ_API_KEY,
    base_url="https://api.groq.com/openai/v1"
)

# Folder Paths
RESUME_FOLDER = "resumes"
PROCESSED_DATA_FOLDER = "processed_data"
os.makedirs(PROCESSED_DATA_FOLDER, exist_ok=True)

# Extract ZIP File
def extract_zip(zip_path, extract_to):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)


# Read Resumes from Folder
def read_resumes(folder_path):
    resumes = []
    for file in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file)
        ext = file.split(".")[-1]
        if ext == "pdf":
            resumes.append({"filename": file, "text": extract_text(file_path)})
        elif ext == "docx":
            doc = docx.Document(file_path)
            text = "\n".join([para.text for para in doc.paragraphs])
            resumes.append({"filename": file, "text": text})
    return resumes

# Adaptive Delay to Handle Rate Limits
def adaptive_wait(wait_time):
    print(f"Rate limit exceeded. Waiting for {wait_time} seconds...")
    time.sleep(wait_time)

# Analyze Resume with Mistral

# Analyze Resume with Mistral and Improved Error Handling
def analyze_resume_mistral(resume_text, job_description):
    prompt = f"""
    You are an AI that evaluates resumes based on job descriptions.
    Return your response **strictly** in the following JSON format:

    {{
        "Key Skills": [],
        "Overall Analysis": "",
        "Certifications & Courses": [],
        "Relevant Projects": [],
        "Soft Skills": [],
        "Overall Match Score": 0-10,
        "Projects Relevance Score": 0-10,
        "Experience Relevance Score": 0-10
    }}

    ### Job Description:
    {job_description}

    ### Resume:
    {resume_text[:2000]}
    """
    retry_count = 0
    max_retries = 5  # Maximum retries before skipping
    wait_time = 2    # Initial wait time

    while retry_count < max_retries:
        try:
            response = client.chat.completions.create(
                model="mistral-saba-24b",
                messages=[
                    {"role": "system", "content": "Return only JSON response without extra text."},
                    {"role": "user", "content": prompt}
                ]
            )

            # Check for empty response
            if not response or not response.choices or not response.choices[0].message.content.strip():
                print("Empty response received. Retrying...")
                retry_count += 1
                time.sleep(wait_time)
                wait_time *= 2  # Exponential backoff
                continue

            # Validate response content
            response_content = response.choices[0].message.content.strip()
            if not response_content:
                print("Received empty response content. Retrying...")
                retry_count += 1
                time.sleep(wait_time)
                wait_time *= 2
                continue

            # Attempt to fix common JSON issues
            response_content = response_content.replace(",}", "}")
            if not response_content.startswith("{"):
                response_content = "{" + response_content.split("{", 1)[-1]
            if not response_content.endswith("}"):
                response_content = response_content.rsplit("}", 1)[0] + "}"

            try:
                analysis = json.loads(response_content)
                for key in ["Overall Match Score", "Projects Relevance Score", "Experience Relevance Score"]:
                    if key in analysis:
                        analysis[key] = round(float(analysis[key]), 2)
                return analysis
            except json.JSONDecodeError:
                print(f"Invalid JSON response after fixing: {response_content}")
                retry_count += 1
                time.sleep(wait_time)
                wait_time *= 2
                continue

        except Exception as e:
            print(f"Error: {str(e)}. Retrying...")
            retry_count += 1
            time.sleep(wait_time)
            wait_time *= 2

    print("Max retries exceeded. Returning empty analysis.")
    return {
        "Key Skills": [],
        "Overall Analysis": "",
        "Certifications & Courses": [],
        "Relevant Projects": [],
        "Soft Skills": [],
        "Overall Match Score": 0,
        "Projects Relevance Score": 0,
        "Experience Relevance Score": 0
    }

# Process Resumes in Batches
def process_resumes_in_batches(resumes, job_description, batch_size=10):
    results = []
    for i in range(0, len(resumes), batch_size):
        batch = resumes[i:i + batch_size]
        for resume in batch:
            analysis = analyze_resume_mistral(resume["text"], job_description)
            results.append({"filename": resume["filename"], "analysis": analysis})
        print(f"Processed batch {i // batch_size + 1}. Waiting to avoid rate limit...")
        time.sleep(1.5)
    return results

# Process All Resumes
def process_all_resumes(zip_path, job_description, resume_output_folder):
    extract_zip(zip_path, resume_output_folder)
    resumes = read_resumes(resume_output_folder)

    results = process_resumes_in_batches(resumes, job_description)
    output_json = os.path.join(PROCESSED_DATA_FOLDER, "resume_analysis.json")
    with open(output_json, "w") as f:
        json.dump(results, f, indent=4)
    print("Resume processing completed.")
    return results
