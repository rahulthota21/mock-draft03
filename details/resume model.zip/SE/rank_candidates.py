from sklearn.preprocessing import MinMaxScaler
import json
import pandas as pd
import os

# Paths
PROCESSED_DATA_FOLDER = "processed_data"
INPUT_JSON = os.path.join(PROCESSED_DATA_FOLDER, "resume_analysis.json")
OUTPUT_JSON = os.path.join(PROCESSED_DATA_FOLDER, "ranked_candidates.json")
OUTPUT_CSV = os.path.join(PROCESSED_DATA_FOLDER, "ranked_candidates.csv")

# Compute Relative Ranking
def compute_relative_ranking():
    # Load Processed Resumes
    with open(INPUT_JSON, "r") as f:
        resume_results = json.load(f)

    # Extract Scores
    scores = [
        [r["analysis"]["Final Score"], 
         r["analysis"]["Experience Relevance"], 
         r["analysis"]["Projects Relevance"], 
         r["analysis"]["Certifications Relevance"]]
        for r in resume_results
    ]

    # Normalize Scores
    scaler = MinMaxScaler()
    normalized_scores = scaler.fit_transform(scores)

    # Assign Relative Ranking
    for i, resume in enumerate(resume_results):
        resume["analysis"]["Relative Ranking Score"] = round(normalized_scores[i][0] * 100, 2)  # Convert to 0-100 scale

    # Sort by Ranking
    ranked_results = sorted(resume_results, key=lambda x: x["analysis"]["Relative Ranking Score"], reverse=True)

    # Save JSON & CSV
    with open(OUTPUT_JSON, "w") as f:
        json.dump(ranked_results, f, indent=4)

    df = pd.DataFrame([
        {"filename": r["filename"], **r["analysis"]} 
        for r in ranked_results
    ])
    df.to_csv(OUTPUT_CSV, index=False)

    print("Ranking Complete!")

if __name__ == "__main__":
    compute_relative_ranking()
