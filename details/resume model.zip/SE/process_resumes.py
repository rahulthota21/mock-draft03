import openai
import json
import os
import pdfminer
from pdfminer.high_level import extract_text
import docx
import numpy as np
import faiss
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
from sentence_transformers import SentenceTransformer
from tqdm import tqdm
import zipfile
import requests

# Load Sentence Transformer Model for Similarity Calculation
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# Set up Groq API for Mixtral-8x7B
client = openai.OpenAI(
    api_key="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",
    base_url="https://api.groq.com/openai/v1"
)

# Folder Paths
RESUME_FOLDER = "resumes"
PROCESSED_DATA_FOLDER = "processed_data"
OUTPUT_JSON = os.path.join(PROCESSED_DATA_FOLDER, "resume_analysis.json")
OUTPUT_CSV = os.path.join(PROCESSED_DATA_FOLDER, "resume_analysis.csv")

os.makedirs(PROCESSED_DATA_FOLDER, exist_ok=True)

# Function to Extract Text from Resumes
def extract_text_from_pdf(pdf_path):
    return extract_text(pdf_path)

def extract_text_from_docx(docx_path):
    doc = docx.Document(docx_path)
    return "\n".join([para.text for para in doc.paragraphs])

# Unzip Uploaded Resume Folder
def extract_zip(zip_path, extract_to=RESUME_FOLDER):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)

# Read Multiple Resumes from a Folder
def read_resumes(folder_path):
    resumes = []
    for file in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file)
        ext = file.split(".")[-1]
        if ext == "pdf":
            resumes.append({"filename": file, "text": extract_text_from_pdf(file_path)})
        elif ext == "docx":
            resumes.append({"filename": file, "text": extract_text_from_docx(file_path)})
    return resumes

# Compute Relevance Using Semantic Similarity
def compute_relevance_score(text, job_description):
    if not text:
        return 0
    job_embedding = embed_model.encode(job_description, convert_to_tensor=True)
    text_embedding = embed_model.encode(text, convert_to_tensor=True)
    score = np.dot(job_embedding.cpu().numpy(), text_embedding.cpu().numpy()) / (
        np.linalg.norm(job_embedding.cpu().numpy()) * np.linalg.norm(text_embedding.cpu().numpy())
    )
    return round(score * 10, 2)

# Analyze Resume with Mixtral-8x7B
def analyze_resume_mixtral(resume_text, job_description):
    prompt = f"""
    You are an AI that evaluates resumes based on job descriptions.
    Return your response **strictly** in the following JSON format:

    {{
        "Key Skills": [],
        "Work Experience Summary": "",
        "Certifications & Courses": [],
        "Relevant Projects": [],
        "Soft Skills": [],
        "Overall Match Score": 0-10
    }}

    ### Job Description:
    {job_description}

    ### Resume:
    {resume_text[:2000]}
    """

    response = client.chat.completions.create(
        model="mixtral-8x7b-32768",
        messages=[{"role": "system", "content": "Return only JSON response without extra text."},
                  {"role": "user", "content": prompt}]
    )

    try:
        return json.loads(response.choices[0].message.content)
    except:
        return {"error": "Invalid JSON response"}

# Function to Process Resume in Parallel with User-Defined Weights
def process_resume(resume, job_description, weightages):
    analysis = analyze_resume_mixtral(resume["text"], job_description)
    analysis["Experience Relevance"] = compute_relevance_score(analysis.get("Work Experience Summary", ""), job_description) * weightages.get("experience", 1)
    analysis["Projects Relevance"] = compute_relevance_score(" ".join(analysis.get("Relevant Projects", [])), job_description) * weightages.get("projects", 1)
    analysis["Certifications Relevance"] = compute_relevance_score(" ".join(analysis.get("Certifications & Courses", [])), job_description) * weightages.get("certifications", 1)

    total_score = (
        analysis["Experience Relevance"] + 
        analysis["Projects Relevance"] + 
        analysis["Certifications Relevance"]
    ) / sum(weightages.values())  # Normalize

    analysis["Final Score"] = round(total_score, 2)
    
    return {"filename": resume["filename"], "analysis": analysis}

# Process and Save Resumes in Parallel
def process_all_resumes(zip_path, job_description, weightages):
    extract_zip(zip_path)
    resumes = read_resumes(RESUME_FOLDER)
    results = []
    
    with ThreadPoolExecutor(max_workers=10) as executor:
        for result in tqdm(executor.map(lambda res: process_resume(res, job_description, weightages), resumes), total=len(resumes)):
            results.append(result)
    
    # Save JSON Output
    with open(OUTPUT_JSON, "w") as f:
        json.dump(results, f, indent=4)
    
    # Save CSV Output
    df = pd.DataFrame([{"filename": r["filename"], **r["analysis"]} for r in results])
    df.to_csv(OUTPUT_CSV, index=False)

    return results

if __name__ == "__main__":
    job_desc = "Looking for a Data Scientist with expertise in Python, Machine Learning, and NLP."
    weightages = {"experience": 3, "projects": 2, "certifications": 1}
    process_all_resumes("resumes.zip", job_desc, weightages)
