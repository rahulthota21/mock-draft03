from fastapi import FastAPI, UploadFile, File, Form
import uvicorn
import os
import shutil
import json
from process_resumes import process_all_resumes
from rank_candidates import compute_relative_ranking

# Define API
app = FastAPI()

# Paths
UPLOAD_FOLDER = "uploads"
PROCESSED_DATA_FOLDER = "processed_data"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PROCESSED_DATA_FOLDER, exist_ok=True)

# API to Upload ZIP File & Start Resume Processing
@app.post("/upload-resumes/")
async def upload_resumes(
    file: UploadFile = File(...),
    job_description: str = Form(...),
    weight_experience: int = Form(...),
    weight_projects: int = Form(...),
    weight_certifications: int = Form(...)
):
    # Save Uploaded ZIP File
    zip_path = os.path.join(UPLOAD_FOLDER, file.filename)
    with open(zip_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Set Weightages
    weightages = {
        "experience": weight_experience,
        "projects": weight_projects,
        "certifications": weight_certifications
    }

    # Process Resumes
    process_all_resumes(zip_path, job_description, weightages)

    # Rank Candidates
    compute_relative_ranking()

    return {"message": "Resumes processed & ranked successfully!", "ranked_candidates": "/ranked-candidates"}

# API to Get Ranked Candidates
@app.get("/ranked-candidates")
async def get_ranked_candidates():
    ranked_json_path = os.path.join(PROCESSED_DATA_FOLDER, "ranked_candidates.json")

    with open(ranked_json_path, "r") as f:
        ranked_data = json.load(f)

    return ranked_data

# Run API Server
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
