'use client';

import {
  Dialog, DialogTitle, DialogContent, DialogActions, TextField, Button, Box,
  Typography, useTheme, IconButton, Stack, Paper, ToggleButtonGroup, ToggleButton,
  InputAdornment, Tooltip, LinearProgress, Collapse, Switch, FormControlLabel, Chip,
} from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import { useDropzone } from 'react-dropzone';
import { motion } from 'framer-motion';
import { useState } from 'react';
import {
  UploadCloud, X, LinkIcon, FileArchive, Info, StickyNote, Trash2, GaugeCircle,
} from 'lucide-react';
import { toast } from 'react-toastify';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { v4 as uuidv4 } from 'uuid';

interface NewProjectModalProps {
  open: boolean;
  onClose: () => void;
  onCreate: (data: any) => void;
}

export default function NewProjectModal({ open, onClose, onCreate }: NewProjectModalProps) {
  const theme = useTheme();
  const router = useRouter();
  const [uploadType, setUploadType] = useState<'file' | 'link'>('file');
  const [files, setFiles] = useState<File[]>([]);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const [uploadSpeed, setUploadSpeed] = useState<Record<string, string>>({});
  const [isUploading, setIsUploading] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [weights, setWeights] = useState({
    experience: 3, projects: 2, certifications: 1, education: 2, skills: 2,
  });

  const {
    control, handleSubmit, reset, watch,
    formState: { errors },
  } = useForm({
    defaultValues: {
      projectTitle: '',
      jobDescription: '',
      resumeLink: '',
      notes: '',
    },
  });

  const onDrop = (accepted: File[]) => {
    setFiles([...files, ...accepted]);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: true,
    accept: {
      'application/pdf': ['.pdf'],
      'application/zip': ['.zip'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
  });

  const handleRemoveFile = (name: string) => {
    setFiles((prev) => prev.filter((f) => f.name !== name));
  };

  const handleClose = () => {
    reset();
    setFiles([]);
    setUploadProgress({});
    setUploadSpeed({});
    setIsUploading(false);
    onClose();
  };
  const onSubmit = async (data: any) => {
    const job_id = uuidv4();
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData?.session?.access_token;

    if (!token) {
      toast.error('Authentication failed. Please log in again.');
      return;
    }

    const projectPayload = {
      job_id,
      title: data.projectTitle,
      status: 'Processing',
      resumes: 0,
      shortlisted: 0,
      waitlisted: 0,
      created_at: new Date().toISOString(),
    };

    // 🚀 EARLY REDIRECT to animation page
    router.push(`/dashboard/recruiter/animation?job=${job_id}`);

    // 🎯 Background upload logic starts here (doesn’t block redirect)
    try {
      // Handle Google Drive Link
      if (uploadType === 'link') {
        if (!/^https:\/\/drive\.google\.com/.test(data.resumeLink)) {
          toast.error('❌ Invalid Google Drive link');
          return;
        }

        await fetch('http://localhost:8000/upload-link/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            job_id,
            resume_link: data.resumeLink,
            job_title: data.projectTitle,
            job_description: data.jobDescription,
            ...weights,
          }),
        });

        await supabase.from('recruiter_projects').insert([projectPayload]);
        return;
      }

      // Handle File Upload
      if (files.length === 0) {
        toast.error('Please upload at least one file');
        return;
      }

      for (const file of files) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('job_id', job_id);
        formData.append('job_title', data.projectTitle);
        formData.append('job_description', data.jobDescription);
        Object.entries(weights).forEach(([key, val]) =>
          formData.append(`weight_${key}`, val.toString())
        );

        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'http://localhost:8000/upload-resumes/', true);
        xhr.setRequestHeader('Authorization', `Bearer ${token}`);

        const startTime = Date.now();

        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable) {
            const percent = Math.round((event.loaded / event.total) * 100);
            const seconds = (Date.now() - startTime) / 1000;
            const speedMBps = (event.loaded / 1024 / 1024 / seconds).toFixed(2);
            setUploadProgress((prev) => ({ ...prev, [file.name]: percent }));
            setUploadSpeed((prev) => ({ ...prev, [file.name]: `${speedMBps} MB/s` }));
          }
        };

        xhr.onload = async () => {
          if (xhr.status === 200) {
            await supabase.from('recruiter_projects').insert([projectPayload]);
          } else {
            toast.error('Upload failed');
          }
        };

        xhr.onerror = () => {
          toast.error('❌ Upload error');
        };

        xhr.send(formData);
      }
    } catch (err) {
      console.error('❌ Upload Exception:', err);
    }
  };
  const jd = watch('jobDescription');
  const notes = watch('notes');
  const totalWeight = Object.values(weights).reduce((acc, v) => acc + v, 0);

  return (
    <Dialog open={open} onClose={handleClose} fullWidth maxWidth="sm" PaperProps={{
      component: motion.div,
      initial: { scale: 0.95, opacity: 0 },
      animate: { scale: 1, opacity: 1 },
      exit: { scale: 0.95, opacity: 0 },
      transition: { duration: 0.3 },
      sx: {
        borderRadius: 4,
        background: 'rgba(20, 20, 20, 0.85)',
        backdropFilter: 'blur(20px)',
        boxShadow: '0 0 30px rgba(0,0,0,0.5)',
      }
    }}>
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700 }}>
        🧠 Create Smart Project
        <IconButton onClick={handleClose}><X size={20} /></IconButton>
      </DialogTitle>

      <DialogContent dividers sx={{ maxHeight: '70vh', overflowX: 'hidden' }}>
        <Stack spacing={3}>
          <Controller name="projectTitle" control={control} rules={{ required: 'Required' }} render={({ field }) => (
            <TextField {...field} label="Project Title" fullWidth error={!!errors.projectTitle} helperText={errors.projectTitle?.message} />
          )} />

          <Controller name="jobDescription" control={control} rules={{ required: 'Required' }} render={({ field }) => (
            <TextField
              {...field}
              label="Job Description"
              fullWidth
              multiline
              rows={3}
              error={!!errors.jobDescription}
              helperText={errors.jobDescription?.message || `${jd?.length || 0}/500 characters`}
              InputProps={{
                endAdornment: (
                  <Tooltip title="Used by AI to match resume relevance">
                    <IconButton size="small"><Info size={16} /></IconButton>
                  </Tooltip>
                ),
              }}
            />
          )} />
          <Box>
            <Typography variant="body2" fontWeight={600} gutterBottom>Resume Source</Typography>
            <ToggleButtonGroup
              value={uploadType}
              exclusive
              onChange={(_, val) => val && setUploadType(val)}
              color="primary"
              size="small"
            >
              <ToggleButton value="file"><FileArchive size={16} style={{ marginRight: 6 }} /> Upload</ToggleButton>
              <ToggleButton value="link"><LinkIcon size={16} style={{ marginRight: 6 }} /> Drive Link</ToggleButton>
            </ToggleButtonGroup>

            <Box mt={2}>
              {uploadType === 'file' ? (
                <>
                  <Paper {...getRootProps()} sx={{
                    p: 3,
                    border: '2px dashed',
                    borderColor: isDragActive ? theme.palette.primary.main : theme.palette.divider,
                    backgroundColor: theme.palette.background.default,
                    textAlign: 'center',
                    borderRadius: 2,
                    transition: '0.3s',
                    cursor: 'pointer',
                  }}>
                    <input {...getInputProps()} />
                    <UploadCloud size={28} />
                    <Typography variant="body2" mt={1}>
                      {files.length > 0
                        ? `${files.length} file(s) ready`
                        : 'Drag & drop ZIP/PDF/DOCX here or click to browse'}
                    </Typography>
                  </Paper>

                  <Stack spacing={1} mt={2}>
                    {files.map((file) => (
                      <Paper key={file.name} sx={{
                        p: 1.5, px: 2, borderRadius: 2,
                        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                        backgroundColor: theme.palette.background.paper,
                      }}>
                        <Box>
                          <Typography fontSize={14} fontWeight={600}>{file.name}</Typography>
                          <Typography fontSize={12} color="text.secondary">
                            {uploadSpeed[file.name] || ''} — {uploadProgress[file.name] || 0}%
                          </Typography>
                          <LinearProgress
                            variant="determinate"
                            value={uploadProgress[file.name] || 0}
                            sx={{ mt: 0.5, height: 6, borderRadius: 5 }}
                          />
                        </Box>
                        <IconButton onClick={() => handleRemoveFile(file.name)}><Trash2 size={16} /></IconButton>
                      </Paper>
                    ))}
                  </Stack>
                </>
              ) : (
                <Controller name="resumeLink" control={control} rules={{ required: 'Required' }} render={({ field }) => (
                  <TextField
                    {...field}
                    label="Google Drive Link"
                    fullWidth
                    error={!!errors.resumeLink}
                    helperText={errors.resumeLink?.message}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <LinkIcon size={16} />
                        </InputAdornment>
                      ),
                    }}
                  />
                )} />
              )}
            </Box>
          </Box>

          <FormControlLabel
            control={<Switch checked={showAdvanced} onChange={() => setShowAdvanced(!showAdvanced)} />}
            label="Advanced Weights"
          />

          <Collapse in={showAdvanced}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Total Weight: {totalWeight}/25
              </Typography>
              <Stack spacing={1.5} mt={1}>
                {Object.entries(weights).map(([key, value]) => (
                  <TextField
                    key={key}
                    type="number"
                    label={`${key.charAt(0).toUpperCase() + key.slice(1)} Weight`}
                    value={value}
                    onChange={(e) =>
                      setWeights((prev) => ({
                        ...prev,
                        [key]: Math.min(5, Math.max(0, parseInt(e.target.value))),
                      }))
                    }
                    inputProps={{ min: 0, max: 5 }}
                    fullWidth
                  />
                ))}
              </Stack>
            </Box>
          </Collapse>

          <Controller name="notes" control={control} render={({ field }) => (
            <TextField
              {...field}
              label="Additional Notes"
              fullWidth
              multiline
              rows={2}
              helperText={`${notes?.length || 0}/300 characters`}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <StickyNote size={16} />
                  </InputAdornment>
                ),
              }}
            />
          )} />
        </Stack>
      </DialogContent>

      <DialogActions>
        <Box flex={1} pl={2}>
          <Chip
            icon={<GaugeCircle size={16} />}
            label={`Total Weight: ${totalWeight}`}
            color={totalWeight > 20 ? 'error' : 'default'}
            size="small"
          />
        </Box>
        <Button onClick={handleClose} disabled={isUploading}>Cancel</Button>
        <Button onClick={handleSubmit(onSubmit)} variant="contained" disabled={isUploading}>
          {isUploading ? 'Uploading...' : 'Create Project'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
