'use client';

import { useEffect, useState } from 'react';
import { Box, Typography, CircularProgress, Button } from '@mui/material';
import { useRouter, useSearchParams } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'react-toastify';

const statusTexts = [
  'Uploading resumes...',
  'Parsing files...',
  'Analyzing candidates...',
  'Ranking based on relevance...',
  'Almost done...',
];

export default function AnimationPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const jobParam = searchParams.get('job');
  const jobId = jobParam === 'loading' ? localStorage.getItem('latest_job_id') : jobParam;

  const [step, setStep] = useState(0);
  const [attempts, setAttempts] = useState(0);

  // Animate status text every 2.5s
  useEffect(() => {
    const interval = setInterval(() => {
      setStep((prev) => (prev < statusTexts.length - 1 ? prev + 1 : prev));
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  // Poll backend for status every 3s
  useEffect(() => {
    if (!jobId) return;

    const pollInterval = setInterval(async () => {
      try {
        const res = await fetch(`http://localhost:8000/status?job_id=${jobId}`);
        const data = await res.json();

        if (data.status === 'completed') {
          clearInterval(pollInterval);
          router.push(`/dashboard/recruiter/results/${jobId}`);
        } else {
          setAttempts((prev) => prev + 1);
          if (attempts >= 15) {
            clearInterval(pollInterval);
            toast.info('Model is still processing. Results may take time, grab a coffee ☕', { autoClose: 5000 });
            router.push(`/dashboard/recruiter/results/${jobId}`);
          }
        }
      } catch (err) {
        console.error('Polling error:', err);
        clearInterval(pollInterval);
        toast.error('Error polling model status');
      }
    }, 3000);

    return () => clearInterval(pollInterval);
  }, [jobId, attempts, router]);

  return (
    <Box
      sx={{
        minHeight: '100vh',
        backgroundColor: '#111111',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        color: '#ffffff',
        p: 4,
      }}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <CircularProgress size={70} thickness={4} />
      </motion.div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.5 }}
        >
          <Typography
            variant="h6"
            sx={{
              mt: 4,
              fontWeight: 500,
              fontFamily: 'Inter, sans-serif',
              color: '#f0f0f0',
            }}
          >
            {statusTexts[step]}
          </Typography>
        </motion.div>
      </AnimatePresence>

      <Button
        variant="outlined"
        sx={{ mt: 4, color: '#fff', borderColor: '#888' }}
        onClick={() => router.push('/dashboard/recruiter')}
      >
        Cancel & Go Back
      </Button>
    </Box>
  );
}
