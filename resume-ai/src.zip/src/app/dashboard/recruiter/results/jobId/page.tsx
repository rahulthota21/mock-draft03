'use client';

import { useEffect, useState } from 'react';
import {
  Box, Typography, CircularProgress, Tabs, Tab, Chip, Avatar, Stack,
  Tooltip, TextField, IconButton, Paper, LinearProgress, Divider, Button
} from '@mui/material';
import { useParams } from 'next/navigation';
import { Document, Page, pdfjs } from 'react-pdf';
import {
  Search, ChevronDown, ChevronUp, Download, ClipboardEdit, Eye, FileText
} from 'lucide-react';

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

export default function ResultsPage() {
  const { jobId } = useParams();
  const [candidates, setCandidates] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [tab, setTab] = useState(0);
  const [loading, setLoading] = useState(true);
  const [notes, setNotes] = useState('');
  const [search, setSearch] = useState('');
  const [sortDesc, setSortDesc] = useState(true);

  useEffect(() => {
    const fetchResults = async () => {
      try {
        const res = await fetch(`http://localhost:8000/export?job_id=${jobId}&format=json`);
        const data = await res.json();
        setCandidates(data || []);
        setSelected(data?.[0] || null);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchResults();
  }, [jobId]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Shortlisted': return 'success';
      case 'Waitlisted': return 'warning';
      case 'Rejected': return 'error';
      default: return 'default';
    }
  };

  const updateStatus = (id: string) => {
    const updated = candidates.map((c) =>
      c.resume_id === id
        ? {
            ...c,
            status:
              c.status === 'Shortlisted'
                ? 'Waitlisted'
                : c.status === 'Waitlisted'
                ? 'Rejected'
                : 'Shortlisted',
          }
        : c
    );
    setCandidates(updated);
  };

  const filtered = candidates
    .filter((c) => c.upload?.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => sortDesc ? b.total_score - a.total_score : a.total_score - b.total_score);

  const downloadCSV = () => {
    const header = 'Filename,Score,Rank,Status';
    const rows = filtered.map((c) => `${c.upload},${c.total_score},${c.rank},${c.status || 'Shortlisted'}`);
    const blob = new Blob([header + '\n' + rows.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `job-${jobId}-results.csv`;
    link.click();
  };

  return (
    <Box display="flex" height="100vh">
      {/* Sidebar */}
      <Box width="35%" p={3} borderRight="1px solid #ddd" overflow="auto">
        <Stack direction="row" alignItems="center" spacing={1} mb={2}>
          <TextField
            size="small"
            placeholder="Search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            fullWidth
            InputProps={{
              startAdornment: <Search size={16} style={{ marginRight: 4 }} />,
            }}
          />
          <Tooltip title="Toggle Sort">
            <IconButton onClick={() => setSortDesc(!sortDesc)}>
              {sortDesc ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
            </IconButton>
          </Tooltip>
          <Tooltip title="Export CSV">
            <IconButton onClick={downloadCSV}>
              <Download size={18} />
            </IconButton>
          </Tooltip>
        </Stack>

        <Typography variant="body2" color="text.secondary" mb={2}>
          {filtered.length} candidates
        </Typography>

        <Stack spacing={2}>
          {filtered.map((c) => (
            <Paper
              key={c.resume_id}
              elevation={selected?.resume_id === c.resume_id ? 3 : 1}
              onClick={() => setSelected(c)}
              sx={{
                p: 2,
                cursor: 'pointer',
                borderRadius: 2,
                border: selected?.resume_id === c.resume_id ? '2px solid #1976d2' : '1px solid #ddd',
                transition: '0.2s',
              }}
            >
              <Stack direction="row" justifyContent="space-between" alignItems="center">
                <Stack direction="row" spacing={1} alignItems="center">
                  <Avatar>{c.upload[0]}</Avatar>
                  <Box>
                    <Typography fontWeight={600} fontSize={14}>{c.upload}</Typography>
                    <Typography fontSize={12} color="text.secondary">
                      Score: {c.total_score} | Rank #{c.rank}
                    </Typography>
                    <LinearProgress
                      variant="determinate"
                      value={c.total_score}
                      sx={{ height: 5, borderRadius: 4, mt: 0.5 }}
                    />
                  </Box>
                </Stack>
                <Chip
                  label={c.status || 'Shortlisted'}
                  color={getStatusColor(c.status || 'Shortlisted')}
                  size="small"
                  onClick={() => updateStatus(c.resume_id)}
                />
              </Stack>
            </Paper>
          ))}
        </Stack>
      </Box>

      {/* Detail Panel */}
      <Box flex={1} p={4} overflow="auto">
        {loading || !selected ? (
          <Box textAlign="center" mt={10}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <Stack direction="row" alignItems="center" spacing={2}>
              <Typography variant="h5" fontWeight={700}>
                {selected.upload}
              </Typography>
              <Chip
                label={`Score: ${selected.total_score}`}
                color="primary"
                size="small"
              />
              <Chip
                label={`Rank #${selected.rank}`}
                variant="outlined"
                size="small"
              />
            </Stack>

            <Tabs value={tab} onChange={(_, t) => setTab(t)} sx={{ mt: 2 }}>
              <Tab label="Summary" icon={<FileText size={16} />} iconPosition="start" />
              <Tab label="Strengths" icon={<ClipboardEdit size={16} />} iconPosition="start" />
              <Tab label="Resume" icon={<Eye size={16} />} iconPosition="start" />
            </Tabs>

            <Divider sx={{ my: 2 }} />

            {tab === 0 && (
              <Stack spacing={2}>
                {Object.entries(selected.analysis || {}).map(([key, val]) => (
                  <Box key={key}>
                    <Typography fontWeight={600}>{key}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {Array.isArray(val) ? val.join(', ') : val}
                    </Typography>
                  </Box>
                ))}
              </Stack>
            )}

            {tab === 1 && (
              <Box>
                <TextField
                  label="Recruiter Notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  fullWidth
                  multiline
                  rows={3}
                  sx={{ mb: 2 }}
                />
                <Typography variant="caption" color="text.secondary">
                  Add internal notes for this candidate. Not visible to others.
                </Typography>
              </Box>
            )}

            {tab === 2 && (
              <Box>
                <Document
                  file={`http://localhost:8000/resumes/${jobId}/${selected.upload}`}
                  onLoadError={(e) => console.error("PDF load error", e)}
                >
                  <Page pageNumber={1} width={600} />
                </Document>
              </Box>
            )}
          </>
        )}
      </Box>
    </Box>
  );
}
