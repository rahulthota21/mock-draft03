export default function StudentDashboard() {
    return (
      <div style={{ padding: "2rem" }}>
        <h2>🎓 Student Dashboard</h2>
        <p>Mock interview panel coming soon...</p>
      </div>
    );
  }
  